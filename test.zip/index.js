'use strict';
const twilio = require('twilio');
const voiceResponse = twilio.twiml.VoiceResponse
exports.handler = (event, context, callback) => {

    var req   = event;
    var phoneNumber = req.pathParameters.phonenumber.toString();
    //console.log("phoneNumber" ,phoneNumber);
    var twimlResponse = new voiceResponse();

    twimlResponse.say('Connecting...',{ voice: 'alice' });

    twimlResponse.dial(phoneNumber);

    //console.log(twimlResponse.toString());
    var response = {
      statusCode: 200,
      headers: {
        "Content-Type": "text/xml"
      },
      body: twimlResponse.toString()
    };
    callback(null, response)


};
